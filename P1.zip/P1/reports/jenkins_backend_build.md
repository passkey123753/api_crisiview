# Jenkins Build Log - Backend API CrisisView

Started by user xxxxxxxx

Obtained Jenkinsfile from git https://github.com/passkey123753/api_crisiview.git
[Pipeline] Start of Pipeline
[Pipeline] node
Running on Jenkins
 in /var/jenkins_home/workspace/deploy-crisis-backend
[Pipeline] {
[Pipeline] stage
[Pipeline] { (Declarative: Checkout SCM)
[Pipeline] checkout
Selected Git installation does not exist. Using Default
The recommended git tool is: NONE
No credentials specified
 > git rev-parse --resolve-git-dir /var/jenkins_home/workspace/deploy-crisis-backend/.git # timeout=10
Fetching changes from the remote Git repository
 > git config remote.origin.url https://github.com/passkey123753/api_crisiview.git # timeout=10
Fetching upstream changes from https://github.com/passkey123753/api_crisiview.git
 > git --version # timeout=10
 > git --version # 'git version 2.47.3'
 > git fetch --tags --force --progress -- https://github.com/passkey123753/api_crisiview.git +refs/heads/*:refs/remotes/origin/* # timeout=10
 > git rev-parse refs/remotes/origin/main^{commit} # timeout=10
Checking out Revision 94574ce312a227e83725c19a9433f79834031f24 (refs/remotes/origin/main)
 > git config core.sparsecheckout # timeout=10
 > git checkout -f 94574ce312a227e83725c19a9433f79834031f24 # timeout=10
Commit message: "Fix SonarQube hostname"
 > git rev-list --no-walk ef8e0645a07acef2e2158301a1c334358498facf # timeout=10
[Pipeline] }
[Pipeline] // stage
[Pipeline] withEnv
[Pipeline] {
[Pipeline] stage
[Pipeline] { (Clone)
[Pipeline] git
Selected Git installation does not exist. Using Default
The recommended git tool is: NONE
No credentials specified
 > git rev-parse --resolve-git-dir /var/jenkins_home/workspace/deploy-crisis-backend/.git # timeout=10
Fetching changes from the remote Git repository
 > git config remote.origin.url https://github.com/passkey123753/api_crisiview.git # timeout=10
Fetching upstream changes from https://github.com/passkey123753/api_crisiview.git
 > git --version # timeout=10
 > git --version # 'git version 2.47.3'
 > git fetch --tags --force --progress -- https://github.com/passkey123753/api_crisiview.git +refs/heads/*:refs/remotes/origin/* # timeout=10
 > git rev-parse refs/remotes/origin/main^{commit} # timeout=10
Checking out Revision 94574ce312a227e83725c19a9433f79834031f24 (refs/remotes/origin/main)
 > git config core.sparsecheckout # timeout=10
 > git checkout -f 94574ce312a227e83725c19a9433f79834031f24 # timeout=10
 > git branch -a -v --no-abbrev # timeout=10
 > git branch -D main # timeout=10
 > git checkout -b main 94574ce312a227e83725c19a9433f79834031f24 # timeout=10
Commit message: "Fix SonarQube hostname"
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Install)
[Pipeline] sh
+ npm install

up to date, audited 403 packages in 3s

76 packages are looking for funding
  run `npm fund` for details

2 moderate severity vulnerabilities

To address all issues (including breaking changes), run:
  npm audit fix --force

Run `npm audit` for details.
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Test)
[Pipeline] sh
+ npm test

> test
> node --experimental-vm-modules node_modules/jest/bin/jest.js

(node:9697) ExperimentalWarning: VM Modules is an experimental feature and might change at any time
(Use `node --trace-warnings ...` to show where the warning was created)
FAIL __tests__/technicien.integration.test.js
  ● Console

    console.log
      ◇ injected env (5) from .env // tip: ◈ secrets for agents [www.dotenvx.com]

      at _log (node_modules/dotenv/lib/main.js:131:11)

  ● Technicien integration tests › CRUD cycle for technicien works via API

    SequelizeConnectionRefusedError: connect ECONNREFUSED 127.0.0.1:3307

    [0m [90m  5 |[39m describe([32m'Technicien integration tests'[39m[33m,[39m () [33m=>[39m {
     [90m  6 |[39m     beforeAll([36masync[39m () [33m=>[39m {
    [31m[1m>[22m[39m[90m  7 |[39m         [36mawait[39m sequelize[33m.[39msync({ force[33m:[39m [36mtrue[39m })[33m;[39m
     [90m    |[39m         [31m[1m^[22m[39m
     [90m  8 |[39m     })[33m;[39m
     [90m  9 |[39m
     [90m 10 |[39m     afterAll([36masync[39m () [33m=>[39m {[0m

      at ConnectionManager.connect (node_modules/sequelize/src/dialects/mysql/connection-manager.js:116:17)
      at ConnectionManager._connect (node_modules/sequelize/src/dialects/abstract/connection-manager.js:332:24)
      at node_modules/sequelize/src/dialects/abstract/connection-manager.js:250:32
      at ConnectionManager.getConnection (node_modules/sequelize/src/dialects/abstract/connection-manager.js:280:7)
      at node_modules/sequelize/src/sequelize.js:638:26
      at MySQLQueryInterface.dropTable (node_modules/sequelize/src/dialects/abstract/query-interface.js:265:5)
      at Function.drop (node_modules/sequelize/src/model.js:1448:12)
      at Sequelize.drop (node_modules/sequelize/src/sequelize.js:927:9)
      at Sequelize.sync (node_modules/sequelize/src/sequelize.js:807:7)
      at Object.<anonymous> (__tests__/technicien.integration.test.js:7:9)

PASS __tests__/incident.routes.test.js
  ● Console

    console.log
      ◇ injected env (5) from .env // tip: ⌘ suppress logs { quiet: true }

      at _log (node_modules/dotenv/lib/main.js:131:11)


Test Suites: 1 failed, 1 passed, 2 total
Tests:       1 failed, 6 passed, 7 total
Snapshots:   0 total
Time:        3.324 s, estimated 4 s
Ran all test suites.
+ true
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (SonarQube Analysis)
[Pipeline] sh
+ sonar-scanner -Dsonar.projectKey=api_crisiview -Dsonar.sources=. -Dsonar.exclusions=node_modules/**,__tests__/**,coverage/** -Dsonar.tests=__tests__ -Dsonar.host.url=http://crisis-sonarqube:9000 -Dsonar.login=sqp_c8a018cae462b0fd8e122d9919dcfb77ba5a69c2
INFO: Scanner configuration file: /opt/sonar-scanner-4.8.1.3023-linux/conf/sonar-scanner.properties
INFO: Project root configuration file: /var/jenkins_home/workspace/deploy-crisis-backend/sonar-project.properties
INFO: SonarScanner 4.8.1.3023
INFO: Java 11.0.17 Eclipse Adoptium (64-bit)
INFO: Linux 6.8.0-110-generic amd64
INFO: User cache: /root/.sonar/cache
INFO: Analyzing on SonarQube server 9.9.8.100196
INFO: Default locale: "en", source code encoding: "UTF-8" (analysis is platform dependent)
INFO: Load global settings
INFO: Load global settings (done) | time=631ms
INFO: Server id: 147B411E-AZ3YYmLNmamCpTm4uZ4W
INFO: User cache: /root/.sonar/cache
INFO: Load/download plugins
INFO: Load plugins index
INFO: Load plugins index (done) | time=404ms
INFO: Load/download plugins (done) | time=6253ms
INFO: Process project properties
INFO: Process project properties (done) | time=39ms
INFO: Execute project builders
INFO: Execute project builders (done) | time=2ms
INFO: Project key: api_crisiview
INFO: Base dir: /var/jenkins_home/workspace/deploy-crisis-backend
INFO: Working dir: /var/jenkins_home/workspace/deploy-crisis-backend/.scannerwork
INFO: Load project settings for component key: 'api_crisiview'
INFO: Load project settings for component key: 'api_crisiview' (done) | time=324ms
INFO: Auto-configuring with CI 'Jenkins'
INFO: Load quality profiles
INFO: Load quality profiles (done) | time=735ms
INFO: Load active rules
INFO: Load active rules (done) | time=13100ms
INFO: Load analysis cache
INFO: Load analysis cache (404) | time=145ms
INFO: Load project repositories
INFO: Load project repositories (done) | time=300ms
INFO: Indexing files...
INFO: Project configuration:
INFO:   Excluded sources: node_modules/**, __tests__/**, coverage/**
INFO: 18 files indexed
INFO: 9107 files ignored because of inclusion/exclusion patterns
INFO: 0 files ignored because of scm ignore settings
INFO: Quality profile for js: Sonar way
INFO: Quality profile for json: Sonar way
INFO: ------------- Run sensors on module API CrisisView
INFO: Load metrics repository
INFO: Load metrics repository (done) | time=288ms
INFO: Sensor JaCoCo XML Report Importer [jacoco]
INFO: 'sonar.coverage.jacoco.xmlReportPaths' is not defined. Using default locations: target/site/jacoco/jacoco.xml,target/site/jacoco-it/jacoco.xml,build/reports/jacoco/test/jacocoTestReport.xml
INFO: No report imported, no coverage information will be imported by JaCoCo XML Report Importer
INFO: Sensor JaCoCo XML Report Importer [jacoco] (done) | time=5ms
INFO: Sensor IaC CloudFormation Sensor [iac]
INFO: 0 source files to be analyzed
INFO: 0/0 source files have been analyzed
INFO: Sensor IaC CloudFormation Sensor [iac] (done) | time=413ms
INFO: Sensor IaC Kubernetes Sensor [iac]
INFO: 0 source files to be analyzed
INFO: 0/0 source files have been analyzed
INFO: Sensor IaC Kubernetes Sensor [iac] (done) | time=187ms
INFO: Sensor JavaScript analysis [javascript]
WARN: Node.js version 20 is not recommended, you might experience issues. Please use a recommended version of Node.js [16, 18]
INFO: 12 source files to be analyzed
INFO: 3/12 files analyzed, current file: /var/jenkins_home/workspace/deploy-crisis-backend/routes/intervention.routes.js
INFO: 12/12 source files have been analyzed
INFO: Hit the cache for 0 out of 12
INFO: Miss the cache for 12 out of 12: ANALYSIS_MODE_INELIGIBLE [12/12]
INFO: Sensor JavaScript analysis [javascript] (done) | time=34769ms
INFO: Sensor TypeScript analysis [javascript]
INFO: No input files found for analysis
INFO: Hit the cache for 0 out of 0
INFO: Miss the cache for 0 out of 0
INFO: Sensor TypeScript analysis [javascript] (done) | time=1ms
INFO: Sensor CSS Rules [javascript]
INFO: No CSS, PHP, HTML or VueJS files are found in the project. CSS analysis is skipped.
INFO: Sensor CSS Rules [javascript] (done) | time=0ms
INFO: Sensor JavaScript/TypeScript Coverage [javascript]
INFO: No LCOV files were found using coverage/lcov.info
WARN: No coverage information will be saved because all LCOV files cannot be found.
INFO: Sensor JavaScript/TypeScript Coverage [javascript] (done) | time=1768ms
INFO: Sensor C# Project Type Information [csharp]
INFO: Sensor C# Project Type Information [csharp] (done) | time=1ms
INFO: Sensor C# Analysis Log [csharp]
INFO: Sensor C# Analysis Log [csharp] (done) | time=187ms
INFO: Sensor C# Properties [csharp]
INFO: Sensor C# Properties [csharp] (done) | time=0ms
INFO: Sensor HTML [web]
INFO: Sensor HTML [web] (done) | time=52ms
INFO: Sensor TextAndSecretsSensor [text]
INFO: 14 source files to be analyzed
INFO: 14/14 source files have been analyzed
INFO: Sensor TextAndSecretsSensor [text] (done) | time=617ms
INFO: Sensor VB.NET Project Type Information [vbnet]
INFO: Sensor VB.NET Project Type Information [vbnet] (done) | time=1ms
INFO: Sensor VB.NET Analysis Log [vbnet]
INFO: Sensor VB.NET Analysis Log [vbnet] (done) | time=71ms
INFO: Sensor VB.NET Properties [vbnet]
INFO: Sensor VB.NET Properties [vbnet] (done) | time=0ms
INFO: Sensor IaC Docker Sensor [iac]
INFO: 1 source file to be analyzed
INFO: 1/1 source file has been analyzed
INFO: Sensor IaC Docker Sensor [iac] (done) | time=394ms
INFO: ------------- Run sensors on project
INFO: Sensor Analysis Warnings import [csharp]
INFO: Sensor Analysis Warnings import [csharp] (done) | time=1ms
INFO: Sensor Zero Coverage Sensor
INFO: Sensor Zero Coverage Sensor (done) | time=68ms
INFO: SCM Publisher SCM provider for this project is: git
INFO: SCM Publisher 13 source files to be analyzed
INFO: SCM Publisher 13/13 source files have been analyzed (done) | time=998ms
INFO: CPD Executor 1 file had no CPD blocks
INFO: CPD Executor Calculating CPD for 9 files
INFO: CPD Executor CPD calculation finished (done) | time=81ms
INFO: Analysis report generated in 455ms, dir size=170.4 kB
INFO: Analysis report compressed in 169ms, zip size=55.9 kB
INFO: Analysis report uploaded in 210ms
INFO: ANALYSIS SUCCESSFUL, you can find the results at: http://crisis-sonarqube:9000/dashboard?id=api_crisiview
INFO: Note that you will be able to access the updated dashboard once the server has processed the submitted analysis report
INFO: More about the report processing at http://crisis-sonarqube:9000/api/ce/task?id=AZ3Y-JTZS0L4WnzIgzR2
INFO: Analysis total time: 1:13.977 s
INFO: ------------------------------------------------------------------------
INFO: EXECUTION SUCCESS
INFO: ------------------------------------------------------------------------
INFO: Total time: 1:25.522s
INFO: Final Memory: 18M/183M
INFO: ------------------------------------------------------------------------
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Build Image)
[Pipeline] sh
+ docker build -t crisis_backend .
#0 building with "default" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile:
#1 transferring dockerfile: 155B 0.0s done
#1 DONE 0.3s

#2 [internal] load metadata for docker.io/library/node:20-alpine
#2 DONE 1.2s

#3 [internal] load .dockerignore
#3 transferring context:
#3 transferring context: 2B done
#3 DONE 0.2s

#4 [internal] load build context
#4 ...

#5 [1/5] FROM docker.io/library/node:20-alpine@sha256:fb4cd12c85ee03686f6af5362a0b0d56d50c58a04632e6c0fb8363f609372293
#5 resolve docker.io/library/node:20-alpine@sha256:fb4cd12c85ee03686f6af5362a0b0d56d50c58a04632e6c0fb8363f609372293 1.0s done
#5 DONE 1.0s

#4 [internal] load build context
#4 transferring context: 25.34MB 4.8s
#4 transferring context: 56.78MB 9.8s done
#4 DONE 10.2s

#6 [2/5] WORKDIR /app
#6 CACHED

#7 [3/5] COPY package*.json ./
#7 DONE 1.8s

#8 [4/5] RUN npm install
#8 27.27 npm warn deprecated inflight@1.0.6: This module is not supported, and leaks memory. Do not use it. Check out lru-cache if you want a good and tested way to coalesce async requests by a key value, which is much more comprehensive and powerful.
#8 28.80 npm warn deprecated dottie@2.0.7: Package no longer supported. Contact Support at https://www.npmjs.com/support for more info.
#8 29.89 npm warn deprecated glob@7.2.3: Old versions of glob are not supported, and contain widely publicized security vulnerabilities, which have been fixed in the current version. Please update. Support for old versions may be purchased (at exorbitant rates) by contacting i@izs.me
#8 32.79 npm warn deprecated glob@10.5.0: Old versions of glob are not supported, and contain widely publicized security vulnerabilities, which have been fixed in the current version. Please update. Support for old versions may be purchased (at exorbitant rates) by contacting i@izs.me
#8 40.70 
#8 40.70 added 402 packages, and audited 403 packages in 37s
#8 40.70 
#8 40.70 76 packages are looking for funding
#8 40.70   run `npm fund` for details
#8 40.71 
#8 40.71 2 moderate severity vulnerabilities
#8 40.71 
#8 40.71 To address all issues (including breaking changes), run:
#8 40.71   npm audit fix --force
#8 40.71 
#8 40.71 Run `npm audit` for details.
#8 40.71 npm notice
#8 40.71 npm notice New major version of npm available! 10.8.2 -> 11.13.0
#8 40.71 npm notice Changelog: https://github.com/npm/cli/releases/tag/v11.13.0
#8 40.71 npm notice To update run: npm install -g npm@11.13.0
#8 40.71 npm notice
#8 DONE 42.3s

#9 [5/5] COPY . .
#9 DONE 13.1s

#10 exporting to image
#10 exporting layers
#10 exporting layers 12.1s done
#10 exporting manifest sha256:6b105b104eb60ac0fb001cc0b2c2c76e52a53d36f0768560dd8c224e827c7d80
#10 exporting manifest sha256:6b105b104eb60ac0fb001cc0b2c2c76e52a53d36f0768560dd8c224e827c7d80 0.0s done
#10 exporting config sha256:add0bf06f09388664272ddb4e07aa4aa28f95231d2f4786f04a1705edfe0935b 0.0s done
#10 exporting attestation manifest sha256:7c54fd75e9414de4fef69106b91011600b48f1c6951bb1948ea697849d24a87f
#10 exporting attestation manifest sha256:7c54fd75e9414de4fef69106b91011600b48f1c6951bb1948ea697849d24a87f 0.1s done
#10 exporting manifest list sha256:bfb87ca28d049c961ebabf2cd074da12a081d505a88a9076ddcd7157fcff2adf 0.0s done
#10 naming to docker.io/library/crisis_backend:latest
#10 naming to docker.io/library/crisis_backend:latest done
#10 unpacking to docker.io/library/crisis_backend:latest
#10 unpacking to docker.io/library/crisis_backend:latest 9.9s done
#10 DONE 22.3s
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Deliver)
[Pipeline] withCredentials
Masking supported pattern matches of $DOCKER_PASS
[Pipeline] {
[Pipeline] sh
+ echo ****
+ docker login -u xxxxxxxx --password-stdin
WARNING! Your password will be stored unencrypted in /root/.docker/config.json.
Configure a credential helper to remove this warning. See
https://docs.docker.com/engine/reference/commandline/login/#credentials-store

Login Succeeded
+ docker tag crisis_backend xxxxxxxxx/crisis_backend:latest
+ docker push pierrick2/crisis_backend:latest
The push refers to repository [docker.io/xxxxxxxxx/crisis_backend]
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
fd9b0f39573c: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
fd9b0f39573c: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
fd9b0f39573c: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
fd9b0f39573c: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
fd9b0f39573c: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
fd9b0f39573c: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
fd9b0f39573c: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
fd9b0f39573c: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
fd9b0f39573c: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
178a6ba5b9d9: Waiting
f5520434c4bb: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
fb09f5cdd10c: Waiting
9bcccf4a4170: Waiting
6a0ac1617861: Waiting
fff4e2c1b189: Pushed
9bcccf4a4170: Pushed
178a6ba5b9d9: Pushed
fb09f5cdd10c: Pushed
b2cbbfe903b0: Pushed
6a0ac1617861: Pushed
fd9b0f39573c: Pushed
f5520434c4bb: Pushed
4feea04c1543: Pushed
latest: digest: sha256:bfb87ca28d049c961ebabf2cd074da12a081d505a88a9076ddcd7157fcff2adf size: 856
[Pipeline] }
[Pipeline] // withCredentials
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Deploy)
[Pipeline] sh
+ docker stop crisis_backend
crisis_backend
+ docker rm crisis_backend
crisis_backend
+ docker run -d --name crisis_backend --network crisisview_default -e DB_HOST=crisis_db -e DB_USER=root -e DB_PASSWORD=root -e DB_NAME=crisiview -e DB_PORT=3306 -p 3001:3001 crisis_backend
e1a919a2280fe1529c8b71d6ba3fad5378e26bb39411fd8238f394ab15093fab
[Pipeline] }
[Pipeline] // stage
[Pipeline] }
[Pipeline] // withEnv
[Pipeline] }
[Pipeline] // node
[Pipeline] End of Pipeline
Finished: SUCCESS

