Started by user xxxxx

Obtained Jenkinsfile from git https://github.com/passkey123753/frontend_crisisview.git
[Pipeline] Start of Pipeline
[Pipeline] node
Running on Jenkins
 in /var/jenkins_home/workspace/deploy-crisis-frontend
[Pipeline] {
[Pipeline] stage
[Pipeline] { (Declarative: Checkout SCM)
[Pipeline] checkout
Selected Git installation does not exist. Using Default
The recommended git tool is: NONE
No credentials specified
 > git rev-parse --resolve-git-dir /var/jenkins_home/workspace/deploy-crisis-frontend/.git # timeout=10
Fetching changes from the remote Git repository
 > git config remote.origin.url https://github.com/passkey123753/frontend_crisisview.git # timeout=10
Fetching upstream changes from https://github.com/passkey123753/frontend_crisisview.git
 > git --version # timeout=10
 > git --version # 'git version 2.47.3'
 > git fetch --tags --force --progress -- https://github.com/passkey123753/frontend_crisisview.git +refs/heads/*:refs/remotes/origin/* # timeout=10
 > git rev-parse refs/remotes/origin/main^{commit} # timeout=10
Checking out Revision 23daf1b053f521bc732f646a374b7ff2fa3347da (refs/remotes/origin/main)
 > git config core.sparsecheckout # timeout=10
 > git checkout -f 23daf1b053f521bc732f646a374b7ff2fa3347da # timeout=10
Commit message: "Utilisation SONAR_TOKEN_FRONT"
 > git rev-list --no-walk c49579c977d844e7c431152b5e3d8543cbe50f80 # timeout=10
[Pipeline] }
[Pipeline] // stage
[Pipeline] withEnv
[Pipeline] {
[Pipeline] stage
[Pipeline] { (Clone)
[Pipeline] git
Selected Git installation does not exist. Using Default
The recommended git tool is: NONE
No credentials specified
 > git rev-parse --resolve-git-dir /var/jenkins_home/workspace/deploy-crisis-frontend/.git # timeout=10
Fetching changes from the remote Git repository
 > git config remote.origin.url https://github.com/passkey123753/frontend_crisisview.git # timeout=10
Fetching upstream changes from https://github.com/passkey123753/frontend_crisisview.git
 > git --version # timeout=10
 > git --version # 'git version 2.47.3'
 > git fetch --tags --force --progress -- https://github.com/passkey123753/frontend_crisisview.git +refs/heads/*:refs/remotes/origin/* # timeout=10
 > git rev-parse refs/remotes/origin/main^{commit} # timeout=10
Checking out Revision 23daf1b053f521bc732f646a374b7ff2fa3347da (refs/remotes/origin/main)
 > git config core.sparsecheckout # timeout=10
 > git checkout -f 23daf1b053f521bc732f646a374b7ff2fa3347da # timeout=10
 > git branch -a -v --no-abbrev # timeout=10
 > git branch -D main # timeout=10
 > git checkout -b main 23daf1b053f521bc732f646a374b7ff2fa3347da # timeout=10
Commit message: "Utilisation SONAR_TOKEN_FRONT"
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Install)
[Pipeline] sh
+ npm install

up to date, audited 376 packages in 3s

147 packages are looking for funding
  run `npm fund` for details

2 moderate severity vulnerabilities

To address all issues (including breaking changes), run:
  npm audit fix --force

Run `npm audit` for details.
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Build)
[Pipeline] sh
+ npm run build

> parkme@0.1.0 build
> next build

▲ Next.js 16.2.4 (Turbopack)

  Creating an optimized production build ...
✓ Compiled successfully in 16.7s
  Running TypeScript ...
  Finished TypeScript in 7.9s ...
  Collecting page data using 1 worker ...
  Generating static pages using 1 worker (0/8) ...
  Generating static pages using 1 worker (2/8) 
  Generating static pages using 1 worker (4/8) 
  Generating static pages using 1 worker (6/8) 
✓ Generating static pages using 1 worker (8/8) in 508ms
  Finalizing page optimization ...

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /admin
├ ○ /admin/incidents
├ ○ /admin/interventions
└ ○ /admin/techniciens


○  (Static)  prerendered as static content

[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (SonarQube Analysis)
[Pipeline] sh
+ sonar-scanner -Dsonar.projectKey=frontend_crisisview -Dsonar.sources=. -Dsonar.exclusions=node_modules/**,.next/**,coverage/** -Dsonar.host.url=http://crisis-sonarqube:9000 -Dsonar.login=sqp_aa8a32ca8afbc49e5c6f91a92f4fcbf2cf3f02df
INFO: Scanner configuration file: /opt/sonar-scanner-4.8.1.3023-linux/conf/sonar-scanner.properties
INFO: Project root configuration file: /var/jenkins_home/workspace/deploy-crisis-frontend/sonar-project.properties
INFO: SonarScanner 4.8.1.3023
INFO: Java 11.0.17 Eclipse Adoptium (64-bit)
INFO: Linux 6.8.0-110-generic amd64
INFO: User cache: /root/.sonar/cache
INFO: Analyzing on SonarQube server 9.9.8.100196
INFO: Default locale: "en", source code encoding: "UTF-8" (analysis is platform dependent)
INFO: Load global settings
INFO: Load global settings (done) | time=277ms
INFO: Server id: 147B411E-AZ3YYmLNmamCpTm4uZ4W
INFO: User cache: /root/.sonar/cache
INFO: Load/download plugins
INFO: Load plugins index
INFO: Load plugins index (done) | time=154ms
INFO: Load/download plugins (done) | time=385ms
INFO: Process project properties
INFO: Process project properties (done) | time=35ms
INFO: Execute project builders
INFO: Execute project builders (done) | time=1ms
INFO: Project key: frontend_crisisview
INFO: Base dir: /var/jenkins_home/workspace/deploy-crisis-frontend
INFO: Working dir: /var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork
INFO: Load project settings for component key: 'frontend_crisisview'
INFO: Load project settings for component key: 'frontend_crisisview' (done) | time=127ms
INFO: Auto-configuring with CI 'Jenkins'
INFO: Load quality profiles
INFO: Load quality profiles (done) | time=499ms
INFO: Load active rules
INFO: Load active rules (done) | time=11308ms
INFO: Load analysis cache
INFO: Load analysis cache (404) | time=78ms
INFO: Load project repositories
INFO: Load project repositories (done) | time=82ms
INFO: Indexing files...
INFO: Project configuration:
INFO:   Excluded sources: node_modules/**, .next/**, coverage/**
INFO: 24 files indexed
INFO: 20538 files ignored because of inclusion/exclusion patterns
INFO: 1 file ignored because of scm ignore settings
INFO: Quality profile for css: Sonar way
INFO: Quality profile for js: Sonar way
INFO: Quality profile for json: Sonar way
INFO: Quality profile for ts: Sonar way
INFO: ------------- Run sensors on module Frontend CrisisView
INFO: Load metrics repository
INFO: Load metrics repository (done) | time=114ms
INFO: Sensor JaCoCo XML Report Importer [jacoco]
INFO: 'sonar.coverage.jacoco.xmlReportPaths' is not defined. Using default locations: target/site/jacoco/jacoco.xml,target/site/jacoco-it/jacoco.xml,build/reports/jacoco/test/jacocoTestReport.xml
INFO: No report imported, no coverage information will be imported by JaCoCo XML Report Importer
INFO: Sensor JaCoCo XML Report Importer [jacoco] (done) | time=4ms
INFO: Sensor IaC CloudFormation Sensor [iac]
INFO: 0 source files to be analyzed
INFO: 0/0 source files have been analyzed
INFO: Sensor IaC CloudFormation Sensor [iac] (done) | time=339ms
INFO: Sensor IaC Kubernetes Sensor [iac]
INFO: 0 source files to be analyzed
INFO: 0/0 source files have been analyzed
INFO: Sensor IaC Kubernetes Sensor [iac] (done) | time=253ms
INFO: Sensor JavaScript analysis [javascript]
WARN: Node.js version 20 is not recommended, you might experience issues. Please use a recommended version of Node.js [16, 18]
INFO: 2 source files to be analyzed
INFO: 2/2 source files have been analyzed
INFO: Hit the cache for 0 out of 2
INFO: Miss the cache for 2 out of 2: ANALYSIS_MODE_INELIGIBLE [2/2]
INFO: Sensor JavaScript analysis [javascript] (done) | time=18781ms
INFO: Sensor TypeScript analysis [javascript]
INFO: Found 1 tsconfig.json file(s): [/var/jenkins_home/workspace/deploy-crisis-frontend/tsconfig.json]
INFO: 8 source files to be analyzed
INFO: Creating TypeScript program
INFO: TypeScript configuration file /var/jenkins_home/workspace/deploy-crisis-frontend/tsconfig.json
ERROR: Error: Argument for '--moduleResolution' option must be: 'node', 'classic', 'node16', 'nodenext'.
ERROR:     at createProgramOptions (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/lib/services/program/program.js:106:15)
ERROR:     at createProgram (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/lib/services/program/program.js:132:28)
ERROR:     at default_1 (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/lib/routing/on-create-program.js:10:57)
ERROR:     at Layer.handle [as handle_request] (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/node_modules/express/lib/router/layer.js:95:5)
ERROR:     at next (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/node_modules/express/lib/router/route.js:144:13)
ERROR:     at Route.dispatch (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/node_modules/express/lib/router/route.js:114:3)
ERROR:     at Layer.handle [as handle_request] (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/node_modules/express/lib/router/layer.js:95:5)
ERROR:     at /var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/node_modules/express/lib/router/index.js:284:15
ERROR:     at Function.process_params (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/node_modules/express/lib/router/index.js:346:12)
ERROR:     at next (/var/jenkins_home/workspace/deploy-crisis-frontend/.scannerwork/.sonartmp/eslint-bridge-bundle/package/node_modules/express/lib/router/index.js:280:10)
ERROR: Failed to create program: Argument for '--moduleResolution' option must be: 'node', 'classic', 'node16', 'nodenext'.
INFO: Creating TypeScript program (done) | time=66ms
INFO: Skipped 8 file(s) because they were not part of any tsconfig.json (enable debug logs to see the full list)
INFO: 8/8 source files have been analyzed
INFO: Hit the cache for 0 out of 0
INFO: Miss the cache for 0 out of 0
INFO: Sensor TypeScript analysis [javascript] (done) | time=260ms
INFO: Sensor CSS Rules [javascript]
INFO: 1 source file to be analyzed
INFO: 1/1 source file has been analyzed
INFO: Hit the cache for 0 out of 0
INFO: Miss the cache for 0 out of 0
INFO: Sensor CSS Rules [javascript] (done) | time=267ms
INFO: Sensor CSS Metrics [javascript]
INFO: Sensor CSS Metrics [javascript] (done) | time=42ms
INFO: Sensor C# Project Type Information [csharp]
INFO: Sensor C# Project Type Information [csharp] (done) | time=1ms
INFO: Sensor C# Analysis Log [csharp]
INFO: Sensor C# Analysis Log [csharp] (done) | time=95ms
INFO: Sensor C# Properties [csharp]
INFO: Sensor C# Properties [csharp] (done) | time=1ms
INFO: Sensor HTML [web]
INFO: Sensor HTML [web] (done) | time=18ms
INFO: Sensor TextAndSecretsSensor [text]
INFO: 14 source files to be analyzed
INFO: 14/14 source files have been analyzed
INFO: Sensor TextAndSecretsSensor [text] (done) | time=652ms
INFO: Sensor VB.NET Project Type Information [vbnet]
INFO: Sensor VB.NET Project Type Information [vbnet] (done) | time=1ms
INFO: Sensor VB.NET Analysis Log [vbnet]
INFO: Sensor VB.NET Analysis Log [vbnet] (done) | time=208ms
INFO: Sensor VB.NET Properties [vbnet]
INFO: Sensor VB.NET Properties [vbnet] (done) | time=0ms
INFO: Sensor IaC Docker Sensor [iac]
INFO: 1 source file to be analyzed
INFO: 1/1 source file has been analyzed
INFO: Sensor IaC Docker Sensor [iac] (done) | time=427ms
INFO: ------------- Run sensors on project
INFO: Sensor Analysis Warnings import [csharp]
INFO: Sensor Analysis Warnings import [csharp] (done) | time=15ms
INFO: Sensor Zero Coverage Sensor
INFO: Sensor Zero Coverage Sensor (done) | time=38ms
INFO: SCM Publisher SCM provider for this project is: git
INFO: SCM Publisher 12 source files to be analyzed
INFO: SCM Publisher 12/12 source files have been analyzed (done) | time=623ms
INFO: CPD Executor 2 files had no CPD blocks
INFO: CPD Executor Calculating CPD for 0 files
INFO: CPD Executor CPD calculation finished (done) | time=0ms
INFO: Analysis report generated in 267ms, dir size=146.5 kB
INFO: Analysis report compressed in 88ms, zip size=31.0 kB
INFO: Analysis report uploaded in 136ms
INFO: ANALYSIS SUCCESSFUL, you can find the results at: http://crisis-sonarqube:9000/dashboard?id=frontend_crisisview
INFO: Note that you will be able to access the updated dashboard once the server has processed the submitted analysis report
INFO: More about the report processing at http://crisis-sonarqube:9000/api/ce/task?id=AZ3ZCG7nS0L4WnzIgzR4
INFO: Analysis total time: 52.393 s
INFO: ------------------------------------------------------------------------
INFO: EXECUTION SUCCESS
INFO: ------------------------------------------------------------------------
INFO: Total time: 56.183s
INFO: Final Memory: 18M/183M
INFO: ------------------------------------------------------------------------
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Build Image)
[Pipeline] sh
+ docker build -t crisis_frontend .
#0 building with "default" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile:
#1 transferring dockerfile: 170B 0.0s done
#1 DONE 0.2s

#2 [internal] load metadata for docker.io/library/node:20-alpine
#2 ...

#3 [auth] library/node:pull token for registry-1.docker.io
#3 DONE 0.0s

#2 [internal] load metadata for docker.io/library/node:20-alpine
#2 DONE 1.4s

#4 [internal] load .dockerignore
#4 transferring context:
#4 transferring context: 2B 0.0s done
#4 DONE 0.2s

#5 [internal] load build context
#5 DONE 0.0s

#6 [1/6] FROM docker.io/library/node:20-alpine@sha256:fb4cd12c85ee03686f6af5362a0b0d56d50c58a04632e6c0fb8363f609372293
#6 resolve docker.io/library/node:20-alpine@sha256:fb4cd12c85ee03686f6af5362a0b0d56d50c58a04632e6c0fb8363f609372293
#6 resolve docker.io/library/node:20-alpine@sha256:fb4cd12c85ee03686f6af5362a0b0d56d50c58a04632e6c0fb8363f609372293 0.1s done
#6 DONE 0.3s

#5 [internal] load build context
#5 transferring context: 82.79MB 4.6s
#5 transferring context: 229.49MB 9.6s
#5 transferring context: 373.54MB 14.7s
#5 transferring context: 524.28MB 19.7s
#5 transferring context: 568.45MB 24.7s
#5 transferring context: 606.12MB 27.4s done
#5 DONE 27.9s

#7 [2/6] WORKDIR /app
#7 CACHED

#8 [3/6] COPY package*.json ./
#8 DONE 2.5s

#9 [4/6] RUN npm install
#9 75.71 
#9 75.71 added 375 packages, and audited 376 packages in 1m
#9 75.72 
#9 75.72 147 packages are looking for funding
#9 75.72   run `npm fund` for details
#9 75.82 
#9 75.82 2 moderate severity vulnerabilities
#9 75.82 
#9 75.82 To address all issues (including breaking changes), run:
#9 75.82   npm audit fix --force
#9 75.82 
#9 75.82 Run `npm audit` for details.
#9 75.83 npm notice
#9 75.83 npm notice New major version of npm available! 10.8.2 -> 11.13.0
#9 75.83 npm notice Changelog: https://github.com/npm/cli/releases/tag/v11.13.0
#9 75.83 npm notice To update run: npm install -g npm@11.13.0
#9 75.83 npm notice
#9 DONE 77.6s

#10 [5/6] COPY . .
#10 DONE 30.7s

#11 [6/6] RUN npm run build
#11 1.606 
#11 1.606 > parkme@0.1.0 build
#11 1.606 > next build
#11 1.606 
#11 3.570 Attention: Next.js now collects completely anonymous telemetry regarding usage.
#11 3.571 This information is used to shape Next.js' roadmap and prioritize features.
#11 3.571 You can learn more, including how to opt-out if you'd not like to participate in this anonymous program, by visiting the following URL:
#11 3.571 https://nextjs.org/telemetry
#11 3.572 
#11 3.850 ▲ Next.js 16.2.4 (Turbopack)
#11 3.850 
#11 4.030   Creating an optimized production build ...
#11 23.41 ✓ Compiled successfully in 18.6s
#11 23.42   Running TypeScript ...
#11 33.94   Finished TypeScript in 10.5s ...
#11 33.98   Collecting page data using 1 worker ...
#11 35.11   Generating static pages using 1 worker (0/8) ...
#11 35.90   Generating static pages using 1 worker (2/8) 
#11 35.90   Generating static pages using 1 worker (4/8) 
#11 35.91   Generating static pages using 1 worker (6/8) 
#11 35.91 ✓ Generating static pages using 1 worker (8/8) in 802ms
#11 35.93   Finalizing page optimization ...
#11 35.98 
#11 35.98 Route (app)
#11 35.98 ┌ ○ /
#11 35.98 ├ ○ /_not-found
#11 35.98 ├ ○ /admin
#11 35.98 ├ ○ /admin/incidents
#11 35.98 ├ ○ /admin/interventions
#11 35.98 └ ○ /admin/techniciens
#11 35.98 
#11 35.99 
#11 35.99 ○  (Static)  prerendered as static content
#11 35.99 
#11 DONE 36.7s

#12 exporting to image
#12 exporting layers
#12 exporting layers 133.3s done
#12 exporting manifest sha256:992de4c1951b77b7340470a138b6010e80fe70af536514ef6d43ef338947969b
#12 exporting manifest sha256:992de4c1951b77b7340470a138b6010e80fe70af536514ef6d43ef338947969b 0.1s done
#12 exporting config sha256:4b469751a575965cee0b656ac256d32dddf0694e0770ae2b09ccebd5c81930b9 0.0s done
#12 exporting attestation manifest sha256:f4345c29104cfaf457a28b7365ce7f3138835f0f4eaf77d2774ba3cb53291697
#12 exporting attestation manifest sha256:f4345c29104cfaf457a28b7365ce7f3138835f0f4eaf77d2774ba3cb53291697 0.2s done
#12 exporting manifest list sha256:0a0250d21ff52c5c913673685bc12602297239f0d86892a80b29a7d8a7f0d690
#12 exporting manifest list sha256:0a0250d21ff52c5c913673685bc12602297239f0d86892a80b29a7d8a7f0d690 0.1s done
#12 naming to docker.io/library/crisis_frontend:latest 0.0s done
#12 unpacking to docker.io/library/crisis_frontend:latest
#12 unpacking to docker.io/library/crisis_frontend:latest 60.1s done
#12 DONE 193.9s
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Deliver)
[Pipeline] withCredentials
Masking supported pattern matches of $DOCKER_PASS
[Pipeline] {
[Pipeline] sh
+ echo ****
+ docker login -u xxxxx --password-stdin
WARNING! Your password will be stored unencrypted in /root/.docker/config.json.
Configure a credential helper to remove this warning. See
https://docs.docker.com/engine/reference/commandline/login/#credentials-store

Login Succeeded
+ docker tag crisis_frontend xxxxx/crisis_frontend:latest
+ docker push pierrick2/crisis_frontend:latest
The push refers to repository [docker.io/xxxxx/crisis_frontend]
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
8741551fe7e0: Waiting
6b08334854d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
d6d113dc470a: Waiting
edf5b9ff7bbf: Waiting
2de4f4bedfcc: Waiting
edf5b9ff7bbf: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
6a0ac1617861: Waiting
4feea04c1543: Waiting
b2cbbfe903b0: Waiting
fff4e2c1b189: Waiting
178a6ba5b9d9: Waiting
6a0ac1617861: Mounted from xxxxx/crisis_backend
4feea04c1543: Mounted from xxxxx/crisis_backend
b2cbbfe903b0: Waiting
fff4e2c1b189: Mounted from xxxxx/crisis_backend
178a6ba5b9d9: Mounted from xxxxx/crisis_backend
b2cbbfe903b0: Mounted from xxxxx/crisis_backend
6b08334854d9: Pushed
d6d113dc470a: Pushed
2de4f4bedfcc: Pushed
8741551fe7e0: Pushed
edf5b9ff7bbf: Pushed
latest: digest: sha256:0a0250d21ff52c5c913673685bc12602297239f0d86892a80b29a7d8a7f0d690 size: 856
[Pipeline] }
[Pipeline] // withCredentials
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Deploy)
[Pipeline] sh
+ docker stop crisis_frontend
crisis_frontend
+ docker rm crisis_frontend
crisis_frontend
+ docker run -d --name crisis_frontend --network crisisview_default -p 3000:3000 crisis_frontend
a69f7eba3c64c8f14f690c80d9b919389ac8f2b2107270c94e5fb0390aa3e402
[Pipeline] }
[Pipeline] // stage
[Pipeline] }
[Pipeline] // withEnv
[Pipeline] }
[Pipeline] // node
[Pipeline] End of Pipeline
Finished: SUCCESS
